<html>
<head>
<style>
table,td
{
border:1px solid black;
}
td,hel
{ 
font-style:bold;
font-size:24px;
color:white;
}
table
{
width:50%;
}
td
{
height:40px;
}
</style>
</head>

<body background="1.jpg">



<a href="home.html" target="_self"><img src="h7.png"></a>
<img src="protein.png" align="right">
<br><br>
<hel><b>DROP SOME SUGGESTIONS.</b></hel>


<form method="post" action="http://localhost/project/form.php">

<table>
<tr>
<td><b>NAME:</b><br></td>
<td><input type="text" size="52" name="name"></td>
<br>
</tr>

<tr>
<td><b>GENDER:</b><br></td>
<td><input type="radio" name="gender" value="female"><b>Female</b>
<input type="radio" name="gender" value="male"><b>Male</b></td>
<br>
</tr>

<tr>
<td><b>E-MAIL:</b><br></td>
<td><input type="text" size="52" name="email"></td>
<br>
</tr>

<tr>
<td><b>SUGGESTIONS:</b><br></td>
<td><textarea name="comment" rows="5" cols="40"></textarea></td>
<br>
</tr>
 
<tr>
<td><input type="image" src="submit.png" alt="Submit"></td>
<td><input type="image" src="reset.png" alt="Reset"></td>
</tr>
</table>

</form>
<?php
$link=mysql_connect('localhost','root',NULL)or die("Database Missing" . mysql_error());
mysql_select_db('feedback',$link)or die("Table Missing" . mysql_error());
   $name = $_POST["name"];
   $gender = $_POST["gender"];
   $email = $_POST["email"];
   $comment = $_POST["comment"];
$sql=mysql_query("INSERT INTO feedback VALUES('$name','$gender','$email','$comment')") or die("Invalid Entry" . mysql_error());

?>
</body>
</html>
